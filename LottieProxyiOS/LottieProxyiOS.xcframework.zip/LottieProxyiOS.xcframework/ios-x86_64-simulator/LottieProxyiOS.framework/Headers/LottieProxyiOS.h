//
//  LottieProxyiOS.h
//  LottieProxyiOS
//
//  Created by Csaba Huszar on 2022. 05. 03..
//

#import <Foundation/Foundation.h>

//! Project version number for LottieProxyiOS.
FOUNDATION_EXPORT double LottieProxyiOSVersionNumber;

//! Project version string for LottieProxyiOS.
FOUNDATION_EXPORT const unsigned char LottieProxyiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LottieProxyiOS/PublicHeader.h>


